
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/manage-user.mts
import { createClient } from "@supabase/supabase-js";
var SUPER_ADMIN_EMAIL = "atakan.battal@kademe.com.tr";
var manage_user_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { status: 200 });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const supabaseUrl = Netlify.env.get("VITE_SUPABASE_URL") || "";
    const supabaseAnonKey = Netlify.env.get("VITE_SUPABASE_ANON_KEY") || "";
    const supabaseServiceKey = Netlify.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
    if (!supabaseServiceKey) {
      return new Response(
        JSON.stringify({ error: "Sunucu yap\u0131land\u0131rma hatas\u0131: SUPABASE_SERVICE_ROLE_KEY eksik" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Yetkisiz: Authorization header eksik" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      );
    }
    const supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });
    const {
      data: { user: caller },
      error: authError
    } = await supabaseClient.auth.getUser();
    if (authError || !caller) {
      return new Response(
        JSON.stringify({ error: "Yetkisiz: Ge\xE7erli oturum bulunamad\u0131" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      );
    }
    const isSuperAdmin = caller.email === SUPER_ADMIN_EMAIL;
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false }
    });
    const { data: callerProfile } = await supabaseAdmin.from("profiles").select("permissions").eq("id", caller.id).single();
    const hasSettingsFull = callerProfile?.permissions?.settings === "full" || caller.user_metadata?.permissions?.settings === "full";
    if (!isSuperAdmin && !hasSettingsFull) {
      return new Response(
        JSON.stringify({ error: "Yetkisiz: Bu i\u015Flem i\xE7in yetkiniz yok" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }
    const body = await req.json();
    const { action, userId, payload } = body;
    if (action === "update_permissions") {
      if (!userId || !payload?.permissions) {
        return new Response(
          JSON.stringify({ error: "userId ve permissions gerekli" }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
      const { permissions, user_metadata } = payload;
      const { data: metaData, error: metaErr } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        user_metadata: { ...user_metadata, permissions }
      });
      if (metaErr) {
        console.error("updateUserById error:", metaErr);
        return new Response(
          JSON.stringify({ error: `user_metadata g\xFCncellenemedi: ${metaErr.message}` }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
      const { data: profileData, error: profileErr } = await supabaseAdmin.from("profiles").update({ permissions }).eq("id", userId).select("id, permissions");
      if (profileErr) {
        console.error("profiles update error:", profileErr);
        return new Response(
          JSON.stringify({ error: `profiles g\xFCncellenemedi: ${profileErr.message}` }),
          { status: 500, headers: { "Content-Type": "application/json" } }
        );
      }
      console.log("update_permissions OK:", {
        userId,
        metaUpdated: !!metaData?.user,
        profileRows: profileData?.length ?? 0,
        savedPermissions: permissions
      });
      return new Response(
        JSON.stringify({
          success: true,
          debug: {
            metaUpdated: !!metaData?.user,
            profileRows: profileData?.length ?? 0
          }
        }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }
    if (action === "update_password") {
      const { newPassword } = payload || {};
      if (!userId || !newPassword || newPassword.length < 6) {
        return new Response(
          JSON.stringify({ error: "userId ve en az 6 karakterli newPassword gerekli" }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        password: newPassword
      });
      if (error) {
        return new Response(
          JSON.stringify({ error: error.message }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
      return new Response(
        JSON.stringify({ success: true }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }
    if (action === "delete_user") {
      if (!userId) {
        return new Response(
          JSON.stringify({ error: "userId gerekli" }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
      if (payload?.email === SUPER_ADMIN_EMAIL) {
        return new Response(
          JSON.stringify({ error: "Ana admin hesab\u0131 silinemez" }),
          { status: 403, headers: { "Content-Type": "application/json" } }
        );
      }
      const { error: cleanupErr } = await supabaseAdmin.rpc("cleanup_user_references", {
        target_user_id: userId
      });
      if (cleanupErr) {
        console.log("cleanup_user_references:", cleanupErr.message);
      }
      const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
      if (error) {
        return new Response(
          JSON.stringify({ error: `Kullan\u0131c\u0131 silinemedi: ${error.message}` }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
      return new Response(
        JSON.stringify({ success: true }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }
    return new Response(
      JSON.stringify({ error: `Bilinmeyen action: ${action}` }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Beklenmeyen hata";
    console.error("manage-user error:", err);
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
};
var config = {
  path: "/api/manage-user"
};
export {
  config,
  manage_user_default as default
};
