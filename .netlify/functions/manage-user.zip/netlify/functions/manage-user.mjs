
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// lib/manageUserHandler.js
import { createClient } from "@supabase/supabase-js";
import ws from "ws";
var SUPER_ADMIN_EMAIL = "atakan.battal@kademe.com.tr";
var JSON_HEADERS = { "Content-Type": "application/json" };
var nodeSupabaseOptions = {
  auth: { autoRefreshToken: false, persistSession: false },
  realtime: { transport: ws }
};
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: JSON_HEADERS });
}
async function handleManageUserRequest(req, env = {}) {
  if (req.method === "OPTIONS") {
    return new Response("ok", { status: 200 });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  try {
    const supabaseUrl = env.VITE_SUPABASE_URL || env.SUPABASE_URL || "";
    const supabaseAnonKey = env.VITE_SUPABASE_ANON_KEY || env.SUPABASE_ANON_KEY || "";
    const supabaseServiceKey = env.SUPABASE_SERVICE_ROLE_KEY || env.VITE_SUPABASE_SERVICE_KEY || "";
    if (!supabaseServiceKey) {
      return jsonResponse(
        { error: "Sunucu yap\u0131land\u0131rma hatas\u0131: SUPABASE_SERVICE_ROLE_KEY eksik" },
        500
      );
    }
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return jsonResponse({ error: "Yetkisiz: Authorization header eksik" }, 401);
    }
    const supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
      ...nodeSupabaseOptions,
      global: { headers: { Authorization: authHeader } }
    });
    const {
      data: { user: caller },
      error: authError
    } = await supabaseClient.auth.getUser();
    if (authError || !caller) {
      return jsonResponse({ error: "Yetkisiz: Ge\xE7erli oturum bulunamad\u0131" }, 401);
    }
    const isSuperAdmin = caller.email === SUPER_ADMIN_EMAIL;
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, nodeSupabaseOptions);
    const { data: callerProfile } = await supabaseAdmin.from("profiles").select("permissions").eq("id", caller.id).single();
    const hasSettingsFull = callerProfile?.permissions?.settings === "full" || caller.user_metadata?.permissions?.settings === "full";
    if (!isSuperAdmin && !hasSettingsFull) {
      return jsonResponse({ error: "Yetkisiz: Bu i\u015Flem i\xE7in yetkiniz yok" }, 403);
    }
    const body = await req.json();
    const { action, userId, payload } = body;
    if (action === "update_permissions") {
      if (!userId || !payload?.permissions) {
        return jsonResponse({ error: "userId ve permissions gerekli" }, 400);
      }
      const { permissions, user_metadata } = payload;
      const { data: metaData, error: metaErr } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        user_metadata: { ...user_metadata, permissions }
      });
      if (metaErr) {
        console.error("updateUserById error:", metaErr);
        return jsonResponse({ error: `user_metadata g\xFCncellenemedi: ${metaErr.message}` }, 400);
      }
      const { data: profileData, error: profileErr } = await supabaseAdmin.from("profiles").update({ permissions }).eq("id", userId).select("id, permissions");
      if (profileErr) {
        console.error("profiles update error:", profileErr);
        return jsonResponse({ error: `profiles g\xFCncellenemedi: ${profileErr.message}` }, 500);
      }
      console.log("update_permissions OK:", {
        userId,
        metaUpdated: !!metaData?.user,
        profileRows: profileData?.length ?? 0,
        savedPermissions: permissions
      });
      return jsonResponse({
        success: true,
        debug: {
          metaUpdated: !!metaData?.user,
          profileRows: profileData?.length ?? 0
        }
      });
    }
    if (action === "update_password") {
      const { newPassword } = payload || {};
      if (!userId || !newPassword || newPassword.length < 6) {
        return jsonResponse({ error: "userId ve en az 6 karakterli newPassword gerekli" }, 400);
      }
      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        password: newPassword
      });
      if (error) {
        return jsonResponse({ error: error.message }, 400);
      }
      return jsonResponse({ success: true });
    }
    if (action === "delete_user") {
      if (!userId) {
        return jsonResponse({ error: "userId gerekli" }, 400);
      }
      if (payload?.email === SUPER_ADMIN_EMAIL) {
        return jsonResponse({ error: "Ana admin hesab\u0131 silinemez" }, 403);
      }
      const { error: cleanupErr } = await supabaseAdmin.rpc("cleanup_user_references", {
        target_user_id: userId
      });
      if (cleanupErr) {
        console.log("cleanup_user_references:", cleanupErr.message);
      }
      const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
      if (error) {
        return jsonResponse({ error: `Kullan\u0131c\u0131 silinemedi: ${error.message}` }, 400);
      }
      return jsonResponse({ success: true });
    }
    return jsonResponse({ error: `Bilinmeyen action: ${action}` }, 400);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Beklenmeyen hata";
    console.error("manage-user error:", err);
    return jsonResponse({ error: message }, 500);
  }
}

// netlify/functions/manage-user.mts
var manage_user_default = async (req, _context) => {
  const env = {
    VITE_SUPABASE_URL: Netlify.env.get("VITE_SUPABASE_URL") || "",
    VITE_SUPABASE_ANON_KEY: Netlify.env.get("VITE_SUPABASE_ANON_KEY") || "",
    SUPABASE_SERVICE_ROLE_KEY: Netlify.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
  };
  return handleManageUserRequest(req, env);
};
var config = {
  path: "/api/manage-user"
};
export {
  config,
  manage_user_default as default
};
